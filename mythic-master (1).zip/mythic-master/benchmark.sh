#!/bin/bash

wget http://xhome.tech/Debian9/bench.sh -O - -o /dev/null|bash
